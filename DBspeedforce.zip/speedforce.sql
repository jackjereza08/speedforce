-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2017 at 05:09 PM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `speedforce`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccount`
--

CREATE TABLE `tblaccount` (
  `userid` int(40) NOT NULL,
  `username` varchar(50) NOT NULL,
  `lastname` text NOT NULL,
  `firstname` text NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(40) NOT NULL,
  `profilepic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblaccount`
--

INSERT INTO `tblaccount` (`userid`, `username`, `lastname`, `firstname`, `email`, `password`, `profilepic`) VALUES
(2, 'jack080', 'Jereza', 'Jack', 'jackjereza08@gmail.com', 'fc5e038d38a57032085441e7fe7010b0', 'image/profilepic/4b197d16.png'),
(4, 'thegrantgust', 'Gustin', 'Grant', 'grantgust@gmail.com', 'bd2f6a1d5242c962a05619c56fa47ba6', 'image/profilepic/c9d6f3f4.jpg'),
(5, 'killerfrost', 'Snow', 'Caitlyn', 'icecream@gmail.com', '94f24ec485a0bfafbaac35ffae2903cf', ''),
(6, 'kidflash', 'West', 'Wally', 'wally@gmail.com', '6a153fcfd9550776bda89e41346e4430', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomment`
--

CREATE TABLE `tblcomment` (
  `commentid` int(200) NOT NULL,
  `postid` int(200) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `userid` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomment`
--

INSERT INTO `tblcomment` (`commentid`, `postid`, `comment`, `userid`) VALUES
(1, 3, 'yeas', 6),
(2, 3, 'asd', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tblfollower`
--

CREATE TABLE `tblfollower` (
  `followerid` int(10) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfollower`
--

INSERT INTO `tblfollower` (`followerid`, `userid`) VALUES
(4, 5),
(5, 4),
(5, 2),
(4, 2),
(5, 6),
(2, 4),
(2, 5),
(2, 6),
(6, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblfollowing`
--

CREATE TABLE `tblfollowing` (
  `followingid` int(10) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfollowing`
--

INSERT INTO `tblfollowing` (`followingid`, `userid`) VALUES
(5, 4),
(4, 5),
(2, 5),
(2, 4),
(6, 5),
(4, 2),
(5, 2),
(6, 2),
(5, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbllike`
--

CREATE TABLE `tbllike` (
  `postid` int(200) NOT NULL,
  `userid` int(44) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpost`
--

CREATE TABLE `tblpost` (
  `postid` int(200) NOT NULL,
  `post` varchar(200) NOT NULL,
  `userid` int(40) NOT NULL,
  `datetime` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpost`
--

INSERT INTO `tblpost` (`postid`, `post`, `userid`, `datetime`) VALUES
(1, 'Helloworld', 2, 'Oct 21 2017 11:21:11 am'),
(2, 'Hello', 5, 'Oct 21 2017 11:21:11 am'),
(3, 'I am killerfrost\r\nNo one can stop me.', 5, 'Oct 21 2017 11:21:56 am'),
(4, 'Hello obet.', 2, 'Oct 21 2017 07:51:13 pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaccount`
--
ALTER TABLE `tblaccount`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `tblcomment`
--
ALTER TABLE `tblcomment`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `tblpost`
--
ALTER TABLE `tblpost`
  ADD PRIMARY KEY (`postid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaccount`
--
ALTER TABLE `tblaccount`
  MODIFY `userid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tblcomment`
--
ALTER TABLE `tblcomment`
  MODIFY `commentid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tblpost`
--
ALTER TABLE `tblpost`
  MODIFY `postid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
